-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2019 at 11:03 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(30) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `number` varchar(20) NOT NULL,
  `income` decimal(20,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `email`, `password`, `number`, `income`) VALUES
('misha', '', 'a', '0', '2570');

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `name` varchar(30) NOT NULL,
  `id` int(5) NOT NULL,
  `password` varchar(30) NOT NULL,
  `number` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `salary` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`name`, `id`, `password`, `number`, `email`, `salary`) VALUES
('batman', 3, '2', '999', 'bat@batmail.com', '5000');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `ordered` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`, `ordered`) VALUES
(1, 'Beef Burger', '16.00', 62),
(1, 'Chicken Burger', '14.50', 24),
(1, 'Smookey Beef Burger', '17.00', 36),
(1, 'Veg Burger', '14.00', 0),
(1, 'Crispy Chicken Burger', '15.00', 32),
(1, 'Chicken Cheese Burger', '15.50', 9),
(2, 'Standard Fries', '5.00', 5),
(2, 'Sweet Potato Fries', '6.00', 2),
(2, 'Crinkle Cut Fries', '5.50', 8),
(2, 'Garlic Fries', '6.50', 0),
(2, 'Waffle Fries', '6.00', 0),
(2, 'Potato Wedges', '5.20', 20),
(3, 'Spicey Chicken Pizza', '22.00', 55),
(3, 'BBQ Temptation Pizza', '23.50', 61),
(3, 'Chicken Hawaiian Pizza', '22.20', 35),
(3, 'Spicy Beef Pizza', '24.00', 27),
(3, 'Beef Pepperoni Pizza', '25.00', 22),
(3, 'Vegi Pizza', '21.00', 26),
(11, 'Milk Tea', '5.00', 0),
(11, 'Green Tea', '6.00', 4),
(11, 'Lemon Tea', '5.00', 0),
(11, 'Black Coffie', '10.00', 0),
(11, 'Milk Coffie', '8.00', 1),
(11, 'cappuccino', '12.00', 39),
(12, 'Mojo', '10.00', 12),
(12, 'Sprite', '10.00', 20),
(12, '7up', '10.00', 0),
(12, 'Coca Cola', '10.00', 4),
(12, 'Mount & Dew', '10.00', 12),
(12, 'Fanta', '10.00', 0),
(13, 'Mango Juice', '15.00', 108),
(13, 'Apple Juice', '14.00', 8),
(13, 'Orange Juice', '14.00', 5),
(13, 'Lemonade', '10.00', 111),
(13, 'Grape Juice', '20.00', 21),
(13, 'Pineapple Juice', '12.50', 11),
(5, 'Oven Baked Pasta', '20.00', 6),
(2, 'Spicy Pasta', '22.00', 0),
(0, 'Chilli Sauce Pasta', '25.00', 5),
(1, 'Chilli Sauce Pasta', '25.00', 5),
(1, 'Beef Oven Baked Pasta', '26.00', 0),
(1, 'Tiger Garden Special Pasta', '23.00', 0),
(1, 'Cheesy Pasta', '21.00', 0),
(2, 'Ultimate Club Sandwich', '15.00', 0),
(2, 'Supreme Club Sandwich', '14.00', 0),
(2, 'Garden Club Sandwich', '16.00', 0),
(2, 'Chicken&Cheese Club Sandwich', '18.00', 0),
(2, 'Cheese Club Sandwich', '16.00', 0),
(2, 'Mutton Sandwich', '15.50', 0),
(5, 'Ultimate Chocolate Utopia Cake', '220.00', 1),
(5, 'New York Cheese Cake', '200.00', 0),
(5, 'White Lavender Cheese Cake', '210.00', 1),
(5, 'Icecream Sundaes', '200.00', 1),
(5, 'Red Velvet Cake', '260.00', 1),
(5, 'Apple Crisp', '190.00', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
